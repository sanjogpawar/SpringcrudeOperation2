package com.example.demo.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Student")
public class StudentModel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Stud_id;
	
	@Column(name = "Stud_name")
	private String Stud_name;
	
	@Column 
	private int age;
	
	@Column(name = "Stud_address")
	private String Stud_address;
	
	@Column(name = "Stud_contact")
	private long Stud_contact;
	
	public StudentModel() {
		
	}

	public int getStud_id() {
		return Stud_id;
	}

	public void setStud_id(int stud_id) {
		Stud_id = stud_id;
	}

	public String getStud_name() {
		return Stud_name;
	}

	public void setStud_name(String stud_name) {
		Stud_name = stud_name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getStud_address() {
		return Stud_address;
	}

	public void setStud_address(String stud_address) {
		Stud_address = stud_address;
	}

	public long getStud_contact() {
		return Stud_contact;
	}

	public void setStud_contact(long stud_contact) {
		Stud_contact = stud_contact;
	}

	@Override
	public String toString() {
		return "StudentModel [Stud_id=" + Stud_id + ", Stud_name=" + Stud_name + ", age=" + age + ", Stud_address="
				+ Stud_address + ", Stud_contact=" + Stud_contact + ", getStud_id()=" + getStud_id()
				+ ", getStud_name()=" + getStud_name() + ", getAge()=" + getAge() + ", getStud_address()="
				+ getStud_address() + ", getStud_contact()=" + getStud_contact() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	
	
	
	

}
