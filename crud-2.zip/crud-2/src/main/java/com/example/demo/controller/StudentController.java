package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.StudentModel;
import com.example.demo.repository.StudentRepository;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	StudentRepository studrepo;
	
	@PostMapping("/post")
	public String Addata(@RequestBody StudentModel smodel) {
		studrepo.save(smodel);
		return "Data Added Successfully";
	}
	@GetMapping("/get")
	public ResponseEntity<List<StudentModel>> getAllStudent()
	{
		List<StudentModel> stud = new ArrayList<>();
		studrepo.findAll().forEach(stud::add);
		return new ResponseEntity<List<StudentModel>>(stud,HttpStatus.OK);
	}
	@PutMapping("/update/{id}")
	public String update(@PathVariable int id,@RequestBody StudentModel smodel) {
		Optional<StudentModel> stm = studrepo.findById(id);
		if(stm.isPresent()) {
			StudentModel sm = stm.get();
			sm.setAge(smodel.getAge());
			sm.setStud_address(smodel.getStud_address());
			sm.setStud_contact(smodel.getStud_contact());
			sm.setStud_name(smodel.getStud_name());
			
			studrepo.save(sm);
			return "Student details update successfully";
		}else {
			return "studen details not exist against id"+id;
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable int id) {
	studrepo.deleteById(id);
	return " record delete successfully";
	}
}
